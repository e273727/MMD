# Windows executable output

Run `build-windows.bat` from the project root on a Windows computer. The generated `EFileMMD.exe` and `EFileMMD-Windows.zip` will be placed in this folder.

The executable must run on one Windows host computer. Other users connect using the LAN address printed by the app in their browser.
